export const InstagramEndpoints = {
  GetByPost: `/p`,
  GetByGraphQL: `/api/graphql`,
} as const;
